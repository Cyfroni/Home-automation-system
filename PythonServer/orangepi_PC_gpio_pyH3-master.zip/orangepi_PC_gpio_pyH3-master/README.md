# orangepi_PC_gpio_pyH3
python control orangepi_PC ext GPIO ALLwinner H3  base on  pyA20 0.2.1


open source   modified  base on  pyA20 

reference 
https://www.olimex.com/wiki/A20-OLinuXino-MICRO
pyA20 
https://pypi.python.org/pypi/pyA20

install ::
	
	python setup.py install 



author :duxingkei chow
email :277563381@qq.com



























